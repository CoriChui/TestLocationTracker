package com.kaonstudio.testlocationtracker.ui;

public class Placeholder {
}
